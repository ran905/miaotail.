# 喵尾巴（MiaoTail）

一个只在句末补后缀的小 App：在 QQ / 微信里打「今天天气不错。」，发出去变成「今天天气不错喵。」。

- 一个安装包（APK），**没有申请 INTERNET 权限**，从系统层面就无法联网、无法上传内容
- 所有设置存在本机 `SharedPreferences`，不写日志、不落盘聊天内容
- 后缀、触发标点、生效应用全部在设置页里改，纯本地可控

实现方式：`AccessibilityService` 监听 `TYPE_VIEW_TEXT_CHANGED`，在句末标点前插入后缀，再用 `ACTION_SET_TEXT` + `ACTION_SET_SELECTION` 写回并恢复光标。

## 界面

奶油底色 + 珊瑚橙强调色，三张圆角卡片：

- **状态卡**：绿/灰小圆点 + 一句话状态 + 「去开启无障碍」描边按钮，从系统设置回来会实时刷新
- **设置卡**：后缀输入框 + 实时示例（后缀本身用橙色加粗高亮，跟着输入变）、触发标点、生效范围、「仅指定应用」的包名列表（默认微信 / QQ / TIM）
- **总开关卡**：左边说明，右边拨动开关
- 底部整宽「保存设置」按钮，页脚一行「不联网 · 不上传 · 卸载即清除」

图标是自己画的矢量爪印：珊瑚橙肉垫 + 四个脚趾，奶油圆角底，Android 8+ 走自适应图标（圆形/方形/水滴形启动器都能正确裁切），旧版本走矢量兜底。

## 编译

三条路，按「需要装多少东西」排序：

| 路线 | 需要什么 | 适合 |
| --- | --- | --- |
| A. GitHub Actions 云编译 | 一个 GitHub 账号，零本地安装 | 不想装 IDE、只用手机传文件 |
| B. Android Studio | 电脑 + 约 3 GB 磁盘 | 以后还想改代码、调 UI |
| C. 命令行 Gradle | 电脑 + JDK 17 + Android SDK（约 2 GB） | 有现成 SDK 环境 |

### A. GitHub Actions（零安装）

1. 在 GitHub 新建一个**私有**仓库（private，别公开，这玩意儿没什么好公示的）
2. 把 `miaotail/` 里的所有文件（含 `.github/`）上传上去
   - 网页端就能拖文件上传；或者用 `git`：
     ```sh
     cd miaotail
     git init && git add . && git commit -m "miaotail"
     git remote add origin https://github.com/<你的账号>/<仓库名>.git
     git push -u origin main
     ```
3. 打开仓库的 **Actions** 标签页 → 选 `Build debug APK` → `Run workflow`
4. 等 3–5 分钟，点进这次 run，在最下面 **Artifacts** 里下载 `miaotail-debug-apk.zip`，解压就是 `app-debug.apk`

仓库自带的 `.github/workflows/build-apk.yml` 已经配好了 JDK 17、Android SDK 和 Gradle 8.7，不用改任何东西。

### 产物怎么变成「一个能直接下的安装包」

`app-debug.apk` 就是完整安装包：debug 签名可以直接装，不用上架、不用开发者账号。两种分发方式：

- **发文件**（最省事）：把 APK 用 QQ/微信发给朋友，对方点开装
- **发链接**：在 GitHub 仓库 **Releases → Draft a new release**，把 APK 作为附件传上去（release 附件是直链，公开仓库时无需登录即可下载；私有仓库需要对方登录）

> 首次安装会遇到「未知来源」提示，允许一次即可。APK 没申请网络权限，安全软件如果有告警，那是无障碍权限触发的，不是联网行为。

### B. Android Studio（本地 IDE）

需要 Android Studio（Koala 以上即可）或本机 Gradle 8.7+ / JDK 17。

**Android Studio（推荐）**

1. `File → Open`，选择 `miaotail/` 目录
2. 等 Gradle sync（首次会下 AGP 8.5.2 + Kotlin 1.9.24）
3. `Build → Build Bundle(s)/APK(s) → Build APK(s)`
4. 产物在 `app/build/outputs/apk/debug/app-debug.apk`

**命令行**

```sh
cd miaotail
gradle wrapper --gradle-version 8.7   # 如果本机没有 wrapper
./gradlew assembleDebug
```

> 没有 wrapper 的 jar，所以命令行方式要么先 `gradle wrapper` 生成，要么直接 `gradle assembleDebug`。

## 装到手机 / 发给朋友

1. 把 `app-debug.apk` 发过去（QQ 传文件、微信传文件、网盘都行）
2. 手机点开安装，允许「安装未知应用」
3. 打开「喵尾巴」，点「打开系统无障碍设置」，找到 **喵尾巴 · 句尾补字** 打开
4. 回到 QQ / 微信随便打一句带「。」的话，看是否补上后缀

### 常见系统坑

- **MIUI / HyperOS / 澎湃**：设置里可能还要开「无障碍快捷方式」和「自启动」；部分版本会在重启后自动关闭第三方无障碍，需要重新打开。
- **Android 13+ 侧载应用**：无障碍页可能灰掉，要先去「应用信息 → 喵尾巴 → 右上角 → 允许受限制的设置」。
- **ColorOS / OriginOS**：允许后台运行 + 锁定后台，否则服务会被杀。
- 装完第一次如果没反应，切一下输入框再打字（服务需要先收到一次窗口变化）。

## 行为细节

- 只在**句末标点**出现时触发（默认 `。！？!?～`，可改）
- 后缀插在标点**前面**：`你好。` → `你好喵。`
- 只响应输入（插入），**不响应删除**：退格删掉「喵」之后不会立刻补回来
- 密码框、非可编辑控件、自己 App 内的输入框都会跳过
- 粘贴整段文字：只有最后一句的句末标点会被处理
- 语音转文字、手写、输入法自带的「快捷短语」不一定触发（取决于是否产生标准文本变更事件）
- 微信/QQ 的聊天输入框是原生 `EditText`，一般能正常工作；如果某个版本不触发，把该 App 加进白名单再试，或确认输入框不是 WebView 实现

## 已知限制

- 依赖无障碍服务，**不是输入法**，所以无法处理「输入框不是标准 EditText」的场景（部分 App 的自绘输入框、网页表单可能只报窗口事件不报文本事件）
- 光标在中间编辑时，写入点之后的位置会整体右移（已做映射），但极端情况下个别 App 仍可能把光标跳到末尾
- 表情、图片、语音消息不受影响（只改文字）

## 安全与隐私

- 无 `INTERNET` 权限，代码里没有任何网络调用
- 不主动读聊天内容：只在文本变化事件里拿当前输入框的文字，重写后立刻丢弃，不做缓存
- 卸载即彻底清除（`allowBackup=false`，不导出数据）

## 目录结构

```
miaotail/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/meow/tail/
        │   ├── MainActivity.kt
        │   └── TailService.kt
        └── res/
            ├── layout/activity_main.xml
            ├── values/{strings,themes}.xml
            └── xml/accessibility_tail.xml
```
