package com.meow.tail

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * 监听输入框的文字变化，在句末标点前插入用户配置的后缀。
 *
 * 设计要点：
 * 1. 只处理「插入」事件（beforeText 长度变短 = 用户在删除，直接跳过，
 *    否则退格删掉「喵」会被立刻补回来，没法删）。
 * 2. 自己写回文字后会再收到一条事件，用 SELF_WRITE_WINDOW_MS 挡掉；
 *    另外「标点前已经是后缀」也会跳过，双重防自激。
 * 3. 写回后重新设置选区，光标原来在末尾就继续在末尾。
 * 4. 密码框、非可编辑控件、自己的包名、白名单外的应用全部跳过。
 */
class TailService : AccessibilityService() {

    companion object {
        const val PREFS = "miao_prefs"
        const val KEY_ENABLED = "enabled"
        const val KEY_SUFFIX = "suffix"
        const val KEY_TRIGGERS = "triggers"
        const val KEY_ALL_APPS = "all_apps"
        const val KEY_PKGS = "pkg_list"

        const val DEFAULT_SUFFIX = "喵"
        const val DEFAULT_TRIGGERS = "。！？!?～"
        const val DEFAULT_PKGS = "com.tencent.mm,com.tencent.mobileqq,com.tencent.tim"

        private const val SELF_WRITE_WINDOW_MS = 500L
    }

    private var lastSelfWriteAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) return
        if (System.currentTimeMillis() - lastSelfWriteAt < SELF_WRITE_WINDOW_MS) return

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        if (!prefs.getBoolean(KEY_ENABLED, true)) return

        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (!isPackageAllowed(prefs, pkg)) return

        val suffix = prefs.getString(KEY_SUFFIX, DEFAULT_SUFFIX).orEmpty()
        val triggers = prefs.getString(KEY_TRIGGERS, DEFAULT_TRIGGERS).orEmpty()
        if (suffix.isEmpty() || triggers.isEmpty()) return

        val node = event.source
            ?: rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: return

        rewriteIfNeeded(node, suffix, triggers, event)
    }

    private fun rewriteIfNeeded(
        node: AccessibilityNodeInfo,
        suffix: String,
        triggers: String,
        event: AccessibilityEvent,
    ) {
        if (!node.isEditable || node.isPassword) return

        val text = node.text?.toString() ?: return
        if (text.isEmpty()) return

        // 只响应插入。删除时不做事，用户才能把多出来的后缀删掉。
        val before = event.beforeText?.toString()
        if (before != null && before.length >= text.length) return

        // 从末尾往前跳过空白，找到最后一个非空白字符
        var index = text.length - 1
        while (index >= 0 && text[index].isWhitespace()) index--
        if (index < 0) return

        // 必须以配置的句末标点结尾
        if (triggers.indexOf(text[index]) < 0) return

        val head = text.substring(0, index)
        if (head.isEmpty()) return

        // 标点前面已经是后缀了，说明这句已经补过
        if (head.endsWith(suffix)) return

        val newText = head + suffix + text.substring(index)

        val selectionStart = node.textSelectionStart
        val selectionEnd = node.textSelectionEnd

        lastSelfWriteAt = System.currentTimeMillis()
        val setText = Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                newText,
            )
        }
        if (!node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, setText)) return

        // 光标映射：插在后缀之前的标点之后，所以超过插入点的位置整体后移
        if (selectionStart >= 0 && selectionEnd >= 0) {
            val start = if (selectionStart >= index) selectionStart + suffix.length else selectionStart
            val end = if (selectionEnd >= index) selectionEnd + suffix.length else selectionEnd
            val selection = Bundle().apply {
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, start)
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, end)
            }
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selection)
        }
    }

    private fun isPackageAllowed(prefs: SharedPreferences, pkg: String): Boolean {
        if (prefs.getBoolean(KEY_ALL_APPS, false)) return true
        val list = prefs.getString(KEY_PKGS, DEFAULT_PKGS).orEmpty()
        return list.split(',')
            .asSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .any { it == pkg }
    }

    override fun onInterrupt() {
        // 不需要处理
    }
}
